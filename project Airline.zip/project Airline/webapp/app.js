document.getElementById("reservationForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;

    alert(`Reservation Successful!\nName: ${name}\nEmail: ${email}\nPhone: ${phone}`);
});