public class Main {
    public static void main(String[] args) {
        System.out.println("Web Application is running. Open your browser and go to the index.html file.");
    }
}